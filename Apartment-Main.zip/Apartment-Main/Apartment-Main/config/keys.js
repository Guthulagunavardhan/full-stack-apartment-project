module.exports = {
    mongoURI: "mongodb+srv://rahulvneni:Rahul%405643@apartment-main.xvryp.mongodb.net/YOUR_DATABASE_NAME?retryWrites=true&w=majority&appName=Apartment-Main",
    secretOrKey: "secret"
};