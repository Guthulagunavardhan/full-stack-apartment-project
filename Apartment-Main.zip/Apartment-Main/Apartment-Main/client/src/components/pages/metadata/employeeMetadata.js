const UserMetadata =  [
    { name:'id', label:'Id', type:'text',hidden: true },
    { name:'employeeId', label:'employeeId', type:'text' },
    { name:'employeeName', label:'employeeName', type:'text' },
    { name:'phoneNumber', label:'phoneNumber', type:'text' },
    { name:'profession', label:'profession', type:'text' }
];

export default UserMetadata;