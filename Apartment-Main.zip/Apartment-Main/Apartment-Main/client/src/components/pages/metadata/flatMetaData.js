const flatMetadata =  [
    { name:'id', label:'Id', type:'text',hidden: true },
    { name:'flatNumber', label:'flatNumber', type:'text' },
    { name:'flatOwnerName', label:'flatOwnerName', type:'text' },
    { name:'flatOwnerNumber', label:'flatOwnerNumber', type:'text' },
    { name:'flatOwnerProfession', label:'flatOwnerProfession', type:'text' }
];

export default flatMetadata;