
export const COMPONENT_TYPE_MAPPER = {
    'lookup': 'Field',
    'text': 'Field',
    'date': 'Field',
    'table': 'View'
    
};