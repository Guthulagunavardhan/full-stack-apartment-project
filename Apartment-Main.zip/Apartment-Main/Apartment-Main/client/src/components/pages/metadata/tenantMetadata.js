const TenantMetadata =  [
    { name:'id', label:'Id', type:'text',hidden: true },
    { name:'tenantId', label:'TenantId', type:'text' },
    { name:'tenantName', label:'TenantName', type:'text' },
    { name:'flatNumber', label:'flatNumber', type:'text' },
    { name:'phoneNumber', label:'PhoneNumber', type:'text' },
    { name:'numberOfPeople', label:'NumberOfPeople', type:'text' },
    { name:'profession', label:'Profession', type:'text' }
];

export default TenantMetadata;