const UserMetadata =  [
    { name:'id', label:'Id', type:'text',hidden: true },
    { name:'name', label:'Name', type:'text' },
    { name:'email', label:'Email', type:'text' },
    { name:'password', label:'Password', type:'password' },
    { name:'userPermission', label:'userPermission', type:'text' }
];

export default UserMetadata;